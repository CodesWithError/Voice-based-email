#Importing required packages
import smtplib                      #It is used to send mail to any Internet machine with an SMTP or ESMTP listener
import speech_recognition as sr     #Speech recognition library
import pyttsx3                      #Text to speech library
from time import sleep              
from email.message import EmailMessage
from playsound import playsound

listener = sr.Recognizer()
engine = pyttsx3.init()

#Function which will enable our system to speak whatever we write as argument
def talk(text):         
    engine.say(text)
    engine.runAndWait()

#Function which will take voice input from user
def get_info(lt):       
    try:
        with sr.Microphone() as source:
            print('\nI am all ears up...')
            playsound('beep.mp3')
            voice = listener.listen(source,phrase_time_limit=lt)
            info = listener.recognize_google(voice)
            print(info)
            return info.lower()
    except:
        talk("Sorry , Did not understand the audio.")
        pass

#Funcction which will first login in the Google account of user using the credentials given by him.
#And then send it to the email address provided by the user
def send_email(receiver, subject, message):         
    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    # Make sure to give app access in your Google account
    server.login('jyotiharbola2016@gmail.com','swhxoxcbamxfzhkz')
    email = EmailMessage()
    email['From'] = 'jyotiharbola2016@gmail.com'
    email['To'] = receiver
    email['Subject'] = subject
    email.set_content(message)
    server.send_message(email)

#Function for taking name,email address, subject and text of the mail from user via voice.
def get_email_info():
    temp=0
    temp2=0
    talk('To Whom you want to send email.')
    name = get_info(2)
    sleep(0.5)
    talk('What is the Username of ' + name + 'before at the rate sign')
    eUsername = get_info(4)
    talk('What is Email Provider of ' + name + 'for Example Gmail, Yahoo')
    eProvider = get_info(4)
    finalEmail = eUsername + "@" + eProvider + ".com"
    receiver= finalEmail
    talk('Is this the correct email of'+name+'?.... Ignore spaces')
    sleep(1)
    confirm=get_info(1)
    #System will ask you for confirmation if there is any misinterpretation then it will ask the address again
    if 'no' in confirm:
        talk('My apologies...It would be better if you type it...')
        receiver=input("Type the email address of "+name+" please...\n")
    else:
        pass
    #Deleting extra spaces,taken by the system, from the email address
    receiver=receiver.replace(" ","")
    print(name+"'s email address is : "+receiver)
    talk('What is the subject of your email that you want to send ?')
    subject = get_info(5)
    #System will ask you for confirmation if there is any misinterpretation then it will ask the subject again
    while(temp==0):
        talk(subject+'.......Is it the correct subject?')
        sleep(1)
        sub_confirm=get_info(2)
        if 'yes' in sub_confirm:
            temp=1
        else:
            talk('My apologies for the mistake')
            talk('Please speak the subject again')
            subject = get_info(5)
            temp=0
    talk('Tell me the text of the body of your email')
    message = get_info(10)
    #System will ask you for confirmation if there is any misinterpretation then it will ask the text again
    while(temp2==0):
        talk(message+'.....Is this the correct text?')
        sleep(2)
        text_confirm=get_info(2)
        if 'yes' in text_confirm:
            temp2=1
        else:
            talk('My apologies for the mistake')
            talk('Please speak the text of the body again')
            message = get_info(15)
            temp2=0
    send_email(receiver, subject, message)
    talk('Hey Master....Your email is sent')
    #It is important to ask the user if he/she wants to send more email or not
    talk('Do you want to send more email apart from '+name+'?')
    send_more = get_info(2)
    if 'yes' in send_more:
        get_email_info()
    else:
        pass

talk('Hi master, I am your email bot...')
get_email_info() #Calling the function to start taking email content.

